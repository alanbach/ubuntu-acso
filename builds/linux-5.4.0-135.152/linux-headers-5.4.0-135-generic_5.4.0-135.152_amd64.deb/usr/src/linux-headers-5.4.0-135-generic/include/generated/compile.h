/* This file is auto generated, version 152 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#152 SMP Sat Dec 24 17:46:32 UTC 2022"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "os-vm-10"
#define LINUX_COMPILER "gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)"
